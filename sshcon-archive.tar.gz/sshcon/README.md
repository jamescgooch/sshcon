# sshcon
ssh connection manager script for bash


sudo chmod 777 sshcon

./sshcon

To start without dependency checks run: bash <(sed -n '82,$p' sshcon
